using FoodDelivery.Lab12.Models;
using Microsoft.EntityFrameworkCore;

namespace FoodDelivery.Lab12.Data;

public static class DbSeeder
{
    public static async Task SeedDataAsync(ApplicationDbContext context)
    {
        // Перевірка усуває дублювання навчальних записів при повторному запуску.
        if (await context.Products.AnyAsync()) return;

        await context.Products.AddRangeAsync(
            new Product { Name = "Борщ", Price = 135m, CategoryId = 1 },
            new Product { Name = "Солянка", Price = 150m, CategoryId = 1 },
            new Product { Name = "Вареники", Price = 170m, CategoryId = 2 },
            new Product { Name = "Деруни", Price = 125m, CategoryId = 2 },
            new Product { Name = "Компот", Price = 45m, CategoryId = 3 },
            new Product { Name = "Узвар", Price = 55m, CategoryId = 3 }
        );
        await context.SaveChangesAsync();
    }
}
