using System.ComponentModel.DataAnnotations;

namespace FoodDelivery.Lab12.DTOs;

public sealed class CreateProductRequest
{
    [Required]
    [MaxLength(120)]
    public string Name { get; set; } = string.Empty;

    [Range(typeof(decimal), "0.01", "999999.99")]
    public decimal Price { get; set; }

    [Range(1, int.MaxValue)]
    public int CategoryId { get; set; }
}

public sealed record ProductResponse(
    int Id, string Name, decimal Price, int CategoryId, string CategoryName
);

public sealed record CategoryResponse(int Id, string Name);
