using FoodDelivery.Lab12.Data;
using FoodDelivery.Lab12.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace FoodDelivery.Lab12.Migrations;

[DbContext(typeof(ApplicationDbContext))]
public partial class ApplicationDbContextModelSnapshot : ModelSnapshot
{
    protected override void BuildModel(ModelBuilder modelBuilder)
    {
        modelBuilder.HasAnnotation("ProductVersion", "8.0.11");

        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasKey(c => c.Id);
            entity.Property(c => c.Id).ValueGeneratedOnAdd().UseIdentityColumn();
            entity.Property(c => c.Name).IsRequired().HasMaxLength(100);
            entity.HasData(
                new { Id = 1, Name = "Супи" },
                new { Id = 2, Name = "Основні страви" },
                new { Id = 3, Name = "Напої" }
            );
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(p => p.Id);
            entity.Property(p => p.Id).ValueGeneratedOnAdd().UseIdentityColumn();
            entity.Property(p => p.Name).IsRequired().HasMaxLength(120);
            entity.Property(p => p.Price).HasColumnType("decimal(18,2)");
            entity.HasIndex(p => p.CategoryId);
            entity.HasOne(p => p.Category)
                  .WithMany(c => c.Products)
                  .HasForeignKey(p => p.CategoryId)
                  .OnDelete(DeleteBehavior.Restrict);
        });
    }
}
