namespace FoodDelivery.Lab12.Models;

// Категорія об'єднує кілька страв (зв'язок 1:N).
public class Category
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public List<Product> Products { get; set; } = new();
}
