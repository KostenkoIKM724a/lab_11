namespace FoodDelivery.Lab12.Models;

// Страва належить одній категорії за зовнішнім ключем CategoryId.
public class Product
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public int CategoryId { get; set; }
    public Category? Category { get; set; }
}
