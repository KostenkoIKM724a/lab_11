using FoodDelivery.Lab12.Data;
using FoodDelivery.Lab12.DTOs;
using FoodDelivery.Lab12.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FoodDelivery.Lab12.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public ProductsController(ApplicationDbContext context) => _context = context;

    // GET /api/products: усі страви разом із назвами категорій.
    [HttpGet]
    public async Task<ActionResult<IEnumerable<ProductResponse>>> GetAll()
    {
        var products = await _context.Products.AsNoTracking()
            .OrderBy(p => p.Id)
            .Select(p => new ProductResponse(
                p.Id, p.Name, p.Price, p.CategoryId, p.Category!.Name))
            .ToListAsync();
        return Ok(products);
    }

    // GET /api/products/1: одна страва за ідентифікатором.
    [HttpGet("{id:int}")]
    public async Task<ActionResult<ProductResponse>> GetById(int id)
    {
        var product = await _context.Products.AsNoTracking()
            .Where(p => p.Id == id)
            .Select(p => new ProductResponse(
                p.Id, p.Name, p.Price, p.CategoryId, p.Category!.Name))
            .FirstOrDefaultAsync();
        return product is null ? NotFound() : Ok(product);
    }

    // POST /api/products: додавання страви у SQL Server.
    [HttpPost]
    public async Task<ActionResult<ProductResponse>> Create(CreateProductRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Name))
            return BadRequest("Назва страви не може бути порожньою.");

        var category = await _context.Categories.FindAsync(request.CategoryId);
        if (category is null)
            return BadRequest("Категорію не знайдено.");

        var product = new Product
        {
            Name = request.Name.Trim(),
            Price = request.Price,
            CategoryId = request.CategoryId
        };
        _context.Products.Add(product);
        await _context.SaveChangesAsync();

        var response = new ProductResponse(
            product.Id, product.Name, product.Price, product.CategoryId, category.Name);
        return CreatedAtAction(nameof(GetById), new { id = product.Id }, response);
    }
}
